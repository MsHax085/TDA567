
import org.junit.runner.RunWith;
import org.junit.runners.Suite;

	@RunWith(Suite.class)
	@Suite.SuiteClasses({
		TestClassFunctA.class,
		TestClassFunctB.class
	})
	public class WorkScheduleTestSuite {
	// nothing goes here	 
	}