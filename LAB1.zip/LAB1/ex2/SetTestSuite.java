import org.junit.runner.RunWith;
import org.junit.runners.Suite;
@RunWith(Suite.class)
@Suite.SuiteClasses({
	WhiteBox.class
})
public class SetTestSuite {
// nothing goes here	 
}