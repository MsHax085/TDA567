
import org.junit.runner.RunWith;
import org.junit.runners.Suite;

	@RunWith(Suite.class)
	@Suite.SuiteClasses({
		TestClass_v2.class,
		TestClass2.class
	})
	public class WorkScheduleTestSuite {
	// nothing goes here	 
	}